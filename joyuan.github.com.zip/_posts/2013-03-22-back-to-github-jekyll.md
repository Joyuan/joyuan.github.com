---
layout: post
date: 2013-03-22 18:37:23
title: 博客搬家回Github（Jekyll）
tags: github jekyll
---

之前[在用farbox的服务](/post/try-farbox.html)，很不错，但是不能预览效果，还是有点瑕疵。

最近又折腾了一下，还是把博客搬家回Github，本来找了一个Jekyll主题（[theOne](http://www.pizn.net/14-11-2012/theone-blog-theme/)），但是自己比较喜欢之前在[点点](http://henter.diandian.com)上弄的主题，于是自己动手丰衣足食，把两个主题结合了一下，就是现在看到的效果。

至于什么Jekyll教程之类的，我就懒得写了，网上一大堆。

欢迎fork，<https://github.com/henter/henter.github.com>

