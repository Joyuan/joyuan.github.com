---
layout: post
date: 2013-04-21 23:53:02
title: 完善扇贝Alfred2 workflow，可添加单词到词库
tags: alfred 扇贝 python
---

今天完善了一下前面发布的基于Alfred2的扇贝workflow

现主要功能如下：
	
* 单词查询，关键词`sb`  :)
* 按回车添加单词到词库，并显示通知
* 按住`command`，回车可以进入单词页面

显示通知用到了`AppleScript`，话说这脚本功能挺强大的。
这是我第一次写这玩意儿，google了半天才写好下面的通知功能，囧。

![AppleScript脚本显示通知](/pic/applescript-notify.png)


显示通知的效果

![AppleScript脚本显示通知](/pic/shanbay-alfred-notify.png)


地址：<https://github.com/henter/Shanbay-Alfred2>


折腾完了

睡觉。
